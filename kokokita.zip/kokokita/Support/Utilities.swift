//
//  Untitled.swift
//  kokokita
//
//  Created by 橋本遼 on 2025/09/20.
//

import Foundation

// JST 表示用のフォーマッタ（保存はUTC、表示はJST）
extension DateFormatter {
    static let jst: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = AppConfig.dateDisplayFormat
        f.timeZone = TimeZone(identifier: "Asia/Tokyo")
        return f
    }()
}

extension Notification.Name {
    static let visitsChanged   = Notification.Name("visitsChanged")
    static let taxonomyChanged = Notification.Name("taxonomyChanged")
}

// 簡易DIコンテナ（Core Data 版 Repository を採用）
final class AppContainer {
    static let shared = AppContainer()

    // Repository はプロトコル型で公開（テストや差し替え容易）
    let repo: (VisitRepository & TaxonomyRepository) = CoreDataVisitRepository()

    // Services
    let loc = DefaultLocationService()
    let poi = MapKitPlaceLookupService()
    let integ = DefaultIntegrityService()

    private init() {}
}
