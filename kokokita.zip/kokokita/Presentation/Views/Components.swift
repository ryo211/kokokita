//
//  Components.swift
//  kokokita
//
//  Created by 橋本遼 on 2025/09/20.
//

import SwiftUI
import Foundation

/// 画面下部に固定表示する大ボタン（PayPay風）
struct BigFooterButton: View {
    let title: String
    let systemImage: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Spacer()
                Label(title, systemImage: systemImage)
                    .font(.title2).bold()
                Spacer()
            }
            .padding()
            .background(Color.accentColor)
            .foregroundColor(.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .shadow(radius: 4)
        }
        .padding(.horizontal)
    }
}

/// 記録一覧のセル
struct VisitRow: View {
    let agg: VisitAggregate
    let nameResolver: (_ labelIds: [UUID], _ groupId: UUID?) -> (labels: [String], group: String?)

    var body: some View {
          let names = nameResolver(agg.details.labelIds, agg.details.groupId)

          VStack(alignment: .leading, spacing: 4) {
              HStack {
                  Text(DateFormatter.jst.string(from: agg.visit.timestampUTC))
                      .font(.footnote)
                      .foregroundStyle(.secondary)
                  Spacer()
              }
              Text(agg.details.title ?? "(無題)")
                  .font(.headline)

              // ラベル／グループ名のバッジを表示
              HStack(spacing: 8) {
                  ForEach(names.labels.prefix(3), id: \.self) { n in
                      Pill(n)
                  }
                  if names.labels.count > 3 {
                      Pill("…+\(names.labels.count - 3)")
                  }
                  if let g = names.group {
                      Pill(g)
                          .foregroundStyle(.blue)
                  }
              }
              .padding(.top, 2)
          }
      }
  }


private struct Pill: View {
    let text: String
    init(_ t: String) { text = t }
    var body: some View {
        Text(text)
            .font(.caption)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color.gray.opacity(0.15))
            .clipShape(Capsule())
    }
}

/// Alert 表示用
struct AlertMsg: Identifiable {
    let id: UUID
    let text: String
}

struct LocationSummarySection: View {
    let timestamp: Date
    let latitude: Double
    let longitude: Double
    let accuracy: Double?
    let address: String?

    @State private var expanded = false

    var body: some View {
        Section("記録") {
            HStack {
                Text(DateFormatter.jst.string(from: timestamp))
                    .font(.footnote)
            }
            // 住所（いつも見える）
            HStack {
                Text(address ?? "取得中…")
                    .foregroundStyle(address == nil ? .secondary : .primary)
                    .font(.footnote)
                    .multilineTextAlignment(.trailing)
                    .lineLimit(2)
                
            }
            

            // 測位の詳細（普段は隠す）
            DisclosureGroup(isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 8) {
                    row("緯度", latitude == 0 ? "-" : "\(latitude)")
                    row("経度", longitude == 0 ? "-" : "\(longitude)")
                    if let a = accuracy {
                        row("誤差", "±\(Int(a)) m")
                    }

                    HStack {
                        if latitude != 0 || longitude != 0 {
                            Link(destination: URL(string: "http://maps.apple.com/?ll=\(latitude),\(longitude)&q=ココキタ")!) {
                                Label("マップで開く", systemImage: "map")
                            }
                        }
                    }
                    .font(.footnote)
                    .padding(.top, 4)
                }
                .padding(.top, 6)
                .font(.footnote)
            } label: {
                Text(expanded ? "非表示" : "詳細を表示")
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func row(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value) }
    }
}
