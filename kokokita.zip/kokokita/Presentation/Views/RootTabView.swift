//
//  RootTabView.swift
//  kokokita
//
//  Created by 橋本遼 on 2025/09/22.
//

import SwiftUI

enum RootTab: Hashable {
    case home, map, calendar, menu
}

struct RootTabView: View {
    @State private var tab: RootTab = .home
    @State private var showCreate = false

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                NavigationStack { HomeView() }
                    .tag(RootTab.home)

                NavigationStack {
                    VStack(spacing: 12) {
                        Image(systemName: "map")
                            .font(.largeTitle)
                        Text("地図（後日実装）")
                            .foregroundStyle(.secondary)
                    }
                    .navigationTitle("地図")
                    .navigationBarTitleDisplayMode(.inline)
                }
                .tag(RootTab.map)

                // 中央はダミー（実ボタンは下部バーに描画）
                Color.clear.tag(RootTab.home)

                NavigationStack {
                    VStack(spacing: 12) {
                        Image(systemName: "calendar")
                            .font(.largeTitle)
                        Text("カレンダー（後日実装）")
                            .foregroundStyle(.secondary)
                    }
                    .navigationTitle("カレンダー")
                    .navigationBarTitleDisplayMode(.inline)
                }
                .tag(RootTab.calendar)

                NavigationStack { MenuHomeView() }
                    .tag(RootTab.menu)
            }
            .toolbar(.hidden, for: .tabBar) // 純正タブバーは隠す

            // カスタム固定フッター
            VStack {
                Spacer()
                CustomBottomBar(
                    current: tab,
                    onSelect: { tab = $0 },
                    onCenterTap: { showCreate = true }
                )
            }
            .ignoresSafeArea(.keyboard, edges: .bottom)
        }
        .sheet(isPresented: $showCreate, onDismiss: {
            NotificationCenter.default.post(name: .visitsChanged, object: nil)  // ★ 追加
        }) {
            CreateView()
                .presentationDetents([.large])
                .ignoresSafeArea(.keyboard, edges: .bottom)
        }
    }
}

private struct CustomBottomBar: View {
    let current: RootTab
    let onSelect: (RootTab) -> Void
    let onCenterTap: () -> Void

    var body: some View {
        ZStack {
            // 背景バー
            Rectangle()
                .fill(.ultraThinMaterial)
                .frame(height: 72)
                .overlay(Divider(), alignment: .top)

            HStack {
                barButton(icon: "house.fill", title: "ホーム", tab: .home)
                barButton(icon: "map.fill", title: "地図", tab: .map)

                // 中央の大ボタン
                Button(action: onCenterTap) {
                    ZStack {
                        Circle()
                            .fill(Color.accentColor)
                            .frame(width: 64, height: 64)
                            .shadow(radius: 6, y: 2)
                        Image(systemName: "mappin.and.ellipse")
                            .foregroundStyle(.white)
                            .font(.title2.weight(.semibold))
                    }
                    .padding(.horizontal, 6)
                }
                .accessibilityLabel("ココキタ")

                barButton(icon: "calendar", title: "カレンダー", tab: .calendar)
                barButton(icon: "ellipsis.circle.fill", title: "メニュー", tab: .menu)
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 8)
        }
    }

    private func barButton(icon: String, title: String, tab: RootTab) -> some View {
        Button {
            onSelect(tab)
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.title3)
                Text(title)
                    .font(.caption2)
            }
            .frame(maxWidth: .infinity)
            .foregroundStyle(current == tab ? .primary : .secondary)
        }
    }
}
