import SwiftUI

struct HomeView: View {
    @StateObject private var vm = HomeViewModel(repo: AppContainer.shared.repo)

    // 名前辞書（型を固定して軽くする）
    private var labelMap: [UUID: String] {
        Dictionary(uniqueKeysWithValues: vm.labels.map { ($0.id, $0.name) })
    }
    private var groupMap: [UUID: String] {
        Dictionary(uniqueKeysWithValues: vm.groups.map { ($0.id, $0.name) })
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                filterBar(vm: vm)
                listContent() // 重い塊は別メソッドへ
            }
        }
        .alert(
            item: Binding(
                get: { vm.alert.map { AlertMsg(id: UUID(), text: $0) } },
                set: { _ in vm.alert = nil }
            )
        ) { msg in
            Alert(title: Text("エラー"),
                  message: Text(msg.text),
                  dismissButton: .default(Text("OK")))
        }
    }

    // MARK: - List（分離して軽く）
    @ViewBuilder
    private func listContent() -> some View {
        List {
            ForEach(vm.items) { agg in
                NavigationLink {
                    DetailView(aggregate: agg) {
                        Task { await vm.reload() }
                    }
                } label: {
                    VisitListRow(agg: agg, labelMap: labelMap, groupMap: groupMap)
                }
                .contextMenu {
                    Button(role: .destructive) {
                        vm.delete(id: agg.id)
                    } label: {
                        Label("削除", systemImage: "trash")
                    }
                }
            }
        }
        .listStyle(.plain)
        .padding(.bottom, 72) // カスタムフッターと重ならないよう底上げ
        .task { await vm.reload() }
        .onReceive(NotificationCenter.default.publisher(for: .visitsChanged)) { _ in
            Task { await vm.reload() }
        }
        .onReceive(NotificationCenter.default.publisher(for: .taxonomyChanged)) { _ in
            Task { await vm.reloadTaxonomyThenData() }
        }
    }

    // MARK: - フィルターバー
    @ViewBuilder
    private func filterBar(vm: HomeViewModel) -> some View {
        // 表示名のマップ（ローカルでOK）
        let lmap: [UUID: String] = Dictionary(uniqueKeysWithValues: vm.labels.map { ($0.id, $0.name) })
        let gmap: [UUID: String] = Dictionary(uniqueKeysWithValues: vm.groups.map { ($0.id, $0.name) })

        let currentLabelTitle = vm.labelFilter.flatMap { lmap[$0] }?.ifNotBlank ?? "すべて"
        let currentGroupTitle = vm.groupFilter.flatMap { gmap[$0] }?.ifNotBlank ?? "すべて"

        HStack {
            // ラベルフィルタ
            Menu {
                Button("すべて") {
                    vm.labelFilter = nil
                    Task { await vm.reload() }
                }
                ForEach(vm.labels
                    .filter { !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
                    .sorted { $0.name.localizedCompare($1.name) == .orderedAscending }
                ) { t in
                    Button(t.name) {
                        vm.labelFilter = t.id
                        Task { await vm.reload() }
                    }
                }
            } label: {
                Label("\(currentLabelTitle)", systemImage: "tag")
            }

            Spacer(minLength: 8)

            // グループフィルタ
            Menu {
                Button("すべて") {
                    vm.groupFilter = nil
                    Task { await vm.reload() }
                }
                ForEach(vm.groups
                    .filter { !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
                    .sorted { $0.name.localizedCompare($1.name) == .orderedAscending }
                ) { t in
                    Button(t.name) {
                        vm.groupFilter = t.id
                        Task { await vm.reload() }
                    }
                }
            } label: {
                Label("\(currentGroupTitle)", systemImage: "folder")
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(.thinMaterial)
    }
}

// MARK: - 行コンポーネント（別ビューで型推論を軽く）
private struct VisitListRow: View {
    let agg: VisitAggregate
    let labelMap: [UUID: String]
    let groupMap: [UUID: String]

    var body: some View {
        let labelNames = agg.details.labelIds.compactMap { labelMap[$0] }
        let groupName  = agg.details.groupId.flatMap { groupMap[$0] }
        VisitRow(agg: agg) { _, _ in
            (labels: labelNames, group: groupName)
        }
    }
}

// 便利拡張
private extension String {
    var ifNotBlank: String? {
        trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : self
    }
}
