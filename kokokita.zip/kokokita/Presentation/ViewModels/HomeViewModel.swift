//
//  HomeViewModel.swift
//  kokokita
//
//  Created by 橋本遼 on 2025/09/20.
//

import Foundation

@MainActor
final class HomeViewModel: ObservableObject {
    @Published var items: [VisitAggregate] = []
    @Published var labelFilter: UUID? = nil
    @Published var groupFilter: UUID? = nil
    @Published var labels: [LabelTag] = []
    @Published var groups: [GroupTag] = []
    @Published var alert: String?

    private let repo: VisitRepository & TaxonomyRepository
    init(repo: VisitRepository & TaxonomyRepository) { self.repo = repo; reload() }

    func reload() {
        do {
            items = try repo.fetchAll(filterLabel: labelFilter, filterGroup: groupFilter)
            labels = try repo.allLabels()
            groups = try repo.allGroups()
        } catch { alert = error.localizedDescription }
    }

    func delete(id: UUID) {
        do { try repo.delete(id: id); reload() }
        catch { alert = error.localizedDescription }
    }
    
    @MainActor
    func loadTaxonomy() {
        do {
            self.labels = try repo.allLabels()
            self.groups = try repo.allGroups()
        } catch {
            self.alert = error.localizedDescription
        }
    }

    @MainActor
    func reloadTaxonomyThenData() async {
        loadTaxonomy()
        await reload()
    }

}
